//go:build no_animations

package app

func init() {
	noAnimations = true
}
