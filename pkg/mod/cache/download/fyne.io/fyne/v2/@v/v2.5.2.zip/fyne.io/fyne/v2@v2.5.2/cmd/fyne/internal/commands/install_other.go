//go:build !windows

package commands

func postInstall(i *Installer) error {
	return nil
}
