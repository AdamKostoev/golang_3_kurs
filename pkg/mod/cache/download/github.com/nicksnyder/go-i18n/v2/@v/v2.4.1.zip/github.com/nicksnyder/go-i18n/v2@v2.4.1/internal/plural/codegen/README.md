# How to upgrade CLDR data

1.  Go to https://github.com/unicode-org/cldr/releases to find the latest release and download the source code.
1.  Unzip and copy `common/supplemental/plurals.xml` to this directory.
1.  Run `generate.sh`.
